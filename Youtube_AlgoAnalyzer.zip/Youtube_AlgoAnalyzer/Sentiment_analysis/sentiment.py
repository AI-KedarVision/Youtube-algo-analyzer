# from textblob import TextBlob

# def analyze_sentiment(comment):
#     analysis = TextBlob(comment)
#     sentiment = analysis.sentiment.polarity  # Range from -1 (negative) to 1 (positive)
#     if sentiment > 0:
#         return "positive"
#     elif sentiment < 0:
#         return "negative"
#     else:
#         return "neutral"

# # Sample dataset with comments
# comments = [
#     "I love this video!",
#     "This is awful.",
#     "Great content.",
#     "Terrible video.",
# ]

# # Analyze sentiments for comments and count positive/negative
# positive_count = 0
# negative_count = 0

# for comment in comments:
#     sentiment = analyze_sentiment(comment)
#     if sentiment == "positive":
#         positive_count += 1
#     elif sentiment == "negative":
#         negative_count += 1

# # Calculate percentages
# total_comments = len(comments)
# positive_percentage = (positive_count / total_comments) * 100
# negative_percentage = (negative_count / total_comments) * 100

# print(f"Positive Comments: {positive_percentage}%")
# print(f"Negative Comments: {negative_percentage}%")




# from textblob import TextBlob
# import csv
# from googleapiclient.discovery import build
# import os

# # Set up the YouTube Data API service
# api_key = 'AIzaSyCKOkfRrWboTpU1LUyVuOiUFbVq_j_QVSM'  # Replace with your YouTube Data API key
# api_service_name = 'youtube'
# api_version = 'v3'
# youtube = build(api_service_name, api_version, developerKey=api_key)

# def fetch_video_comments(video_id):
#     comments = []
#     page_token = None

#     while True:
#         response = youtube.commentThreads().list(
#             part='snippet',
#             videoId=video_id,
#             textFormat='plainText',
#             maxResults=1000,  # Adjust this number as needed
#             pageToken=page_token
#         ).execute()

#         for item in response.get('items', []):
#             comment = item['snippet']['topLevelComment']['snippet']['textDisplay']
#             comments.append(comment)

#         page_token = response.get('nextPageToken')

#         if not page_token:
#             break

#     return comments

# def analyze_sentiment(comment):
#     analysis = TextBlob(comment)
#     sentiment = analysis.sentiment.polarity  # Range from -1 (negative) to 1 (positive)
#     if sentiment > 0:
#         return "positive"
#     elif sentiment < 0:
#         return "negative"
#     else:
#         return "neutral"

# # Sample dataset with video IDs
# video_ids = [
#     "M4UhI-lEglE",
#     "kisHCaQOHYs",

# ]

# # Initialize the CSV file
# csv_filename = "sentiment_analysis.csv"
# with open(csv_filename, 'w', newline='', encoding='utf-8') as csv_file:
#     fieldnames = ['VideoID', 'Positive%', 'Negative%']
#     writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
#     writer.writeheader()

#     for video_id in video_ids:
#         # Fetch comments for the video
#         comments = fetch_video_comments(video_id)

#         positive_count = 0
#         negative_count = 0

#         for comment in comments:
#             sentiment = analyze_sentiment(comment)
#             if sentiment == "positive":
#                 positive_count += 1
#             elif sentiment == "negative":
#                 negative_count += 1

#         total_comments = len(comments)
#         positive_percentage = (positive_count / total_comments) * 100
#         negative_percentage = (negative_count / total_comments) * 100

#         # Write the results to the CSV file
#         writer.writerow({'VideoID': video_id, 'Positive%': positive_percentage, 'Negative%': negative_percentage})

# print(f"Sentiment analysis results have been saved to {csv_filename}")




# from textblob import TextBlob
# import csv
# from googleapiclient.discovery import build
# import os

# # Set up the YouTube Data API service
# api_key = 'AIzaSyCKOkfRrWboTpU1LUyVuOiUFbVq_j_QVSM'  # Replace with your YouTube Data API key
# api_service_name = 'youtube'
# api_version = 'v3'
# youtube = build(api_service_name, api_version, developerKey=api_key)

# def fetch_video_comments(video_id):
#     comments = []
#     page_token = None

#     while True:
#         response = youtube.commentThreads().list(
#             part='snippet',
#             videoId=video_id,
#             textFormat='plainText',
#             maxResults=28500,  # Adjust this number as needed
#             pageToken=page_token
#         ).execute()

#         for item in response.get('items', []):
#             comment = item['snippet']['topLevelComment']['snippet']['textDisplay']
#             comments.append(comment)

#         page_token = response.get('nextPageToken')

#         if not page_token:
#             break

#     return comments

# def analyze_sentiment(comment):
#     analysis = TextBlob(comment)
#     sentiment = analysis.sentiment.polarity  # Range from -1 (negative) to 1 (positive)
#     if sentiment > 0:
#         return "positive"
#     elif sentiment < 0:
#         return "negative"
#     else:
#         return "neutral"

# # Sample dataset with video IDs
# video_ids = ['z-k5uS7ALXk', 't_tROsjwsqk', 'RnvCbquYeIM', 'bC-BYhuFUtY', 's3ScJ_FwaZk', 'uihEg92u9Vg', '44Wp3WE1AHs', 'tnxektauwjM', '1kUE0BZtTRc', '5uz6xOFWi4A', '1To25taIfME', 'N-yALPEpV4w', 'xRZKlDFNgRQ', '68UgJkTQw6E', 'VadUK8-5OSA', 'c_npKjQH_20', '6ci2IO8OuCw', 'LpQxeGtZF2o', 'xhED_ZxC9NQ', 'b1LQSezKxnA', 'lIzWgBWF3SQ', 'Tbm3aXkakEI', 'gcTBEiUTyXE', 'yf2PRpBBEZY', 'WVcsmdc4KH0', 'iHw8x5TyE5g', '5J0YrtobLhg', 'lgZBlD-TCFE', 'NOsXj_0zfqs', 'vtQazMyKrYk', '7OpM_zKGE4o', 'toLCV28uofA', 'TjCc7PcSzR4', 'Q5hDh12XTyU', 'nVl17JLn_u0', 'b8Fbs57WhlM', 'FBXrD4miZOI', 'Uoqo9EjGhPQ', 'zatRz1-PnsA', 't0iL9JJ6Cm8', '6xKt0HrG9Zs', 'EoTVtB-cSps', 'n-nqEFM-6YM', 'yEcYaJED0_E', 'lCNK-Xtnfhk', 
# 'GmOIFDk0jac', 'dEFCgOnpzDQ', 'sz67vUb6Di8', '_y3ZGgDSEk0', 'lGAJ7W7m20A', 'BB7O9crQHY0', 'OpEB6hCpIGM', 'cp6lifuYXFw', 'QP_HbQ5cWSk', 'pWAD9b0DHuc', 'rjbq_Q0yEbo', '94fcQh5epDQ', '_cGkG3CYQd0', '9N4ahe89lew', 'sTnIlKcJQfY', 'TnTpLwUX13A', 'MT4GMd0H5mE', 'juH6QK7KqRw', '2r48_g-yO4c', 'IGw9bU-bdbQ', '9dXKlErU4Ng', 'BVjebOjqgd0', '9OLxBvLvCoM', 'R_oj993n73c', 'b_lT6mJM_fA', 'UKkYmnXgBQo', 'VRtLI96g_RU', 'mKRGNCjRigY', '4rOoVGYJK6w', 'hoKGO_UckuQ', '-BiftyeKY6M', 'N2gFdFhyO_A', 'QokkfE9Ne1o', 'RByIfmOw9pg', 'I1tyo8qvU70', 'rup9Ut-gbK4', 'Qs0QZJ0rea0', 'GtyZ7YJqccU', 'IAitPdqPuk4', 'cM9uSRrdDaY', '0ahY0TBi_QE', '3sUug1kfNps', 'ft5dWEB_EKg', 'sYfOBSGBa7Q', '5HgMeY4zzDU', '9CBbKLm4iWw', 'eALxn2B6z2w', 'IxyvVkeW7Nk', 'Qb37EEXmNRY', '7pH4WQZDoac', 'nOc15wV1uSg', 'WzLtMcM2ApE', 'j3abwtzzv28', '1STaZYZ-P1w', 'O9pwV3JoqwA', '94Qqzbz7hZE', 'la5c6w_pt1g', 'zm0jslIE1kk', 'RAXbohaBGt8', 'pqX1D5AQFfo', 'lmtOuAed5nM', 'OPVUrO-_7SM', 'XXu15NlOuGo', 'wdMqOmGb-vY', 'c1adiK8nLbA', 'DROZUstnsnw', 'rsLuoDJNpp0', 'K2SBjf1O0HU', '1nicf4RjU00', 'r-q5V6LDxEY', 'wId3I9gFJ2w', 'cN-XsiZ_kww', 'qlaylALL870', 'p71xuG_dP7M', 'L0Oql0fz8DM', 'vo-pdOjE2ik', 'lJjOWAlPJDA', 'k7QVw8TIArg', '2dkmjJZD9_M', '1HpxZ9ilSzQ', 'DebZ9xfGX5A', 'UNv1JQlBzxQ', 'Bclz4yyCIMQ', 'efdh0WmAKTs', 'sAu3LVktMwE', 'f5Iq6E2WqRc', 'p6CF-umWLZg', 'bfdEf9tVK_M', 'S758wEniU0c', 'MuYdfxanAk8', 'aHzltu6Tvl8', '0vQtyBacabg', 'YGEfjCvSmnw', 'DYGQGygGwG8', 'uUmtJIBibMM', '0vo9ZaBQ09Q', 'Lj1AKs9HOUU', '5t9lsTJ-Mb0', '_q-aJ3FwazA', 'ITxNK5J5PYw', 'vvoMavzESK4', '8I2cVnGliTE', '10gpEw5cNUQ', 'PNKMqmHqWiQ', 'WqTmKaz5EPU', 'KoZyaIecWCI', 'RnvCbquYeIM', 'PBkmOhOk8nk', '44Wp3WE1AHs', 'djcPk94_BCc', 'zfz52w7znEw', 'mM2nNyaZ_Do', 'HKHf0L1ENBQ', 'u4hik3LL60U', '5VANDcwEUuo', '3UIy4bFdloA', 'rwQxFv4WnYo', '8IfDn7Pm9mw', 'Giek094C_l4', 'Zq_h-Yt7CCQ', '3roITeXVWuE', 'dBXCehEvEjA', 'x0idDI919W4', 'Ms--0d7Oh0s', 'QysiRwibglg', 'qPxe-FCYriM', 'DxY7kF3yknE', 'rpgaXF84Xec', 'qQT49QNiIZo', 'vSmveY2tf0Y', 'bsQBSVJoV04', 'CB6wDVMKSQg', '0_RRKePSjL4', 'ErcWKxYyYEw', 'wGlSXTorZHE', 'bC-BYhuFUtY', 'o0fbnY699Mo', '7Vgq2z_FjWc', 'ygkhD5Cd7SY', '90Ethpq--OM', 'FFqfX11C__0', 'Eg4dNgwpfzg', 'M9oCbp7Di58', 'EWV4e453y8Y', 'D_9KArqXK9U', '5WwzvpKGQS0', '5I9SFnlJI48', 'zbCWGJUVWs0', 'zSOcTm-8-ag', 'KWkknQPQXLc', 'l7dvi7dCGoo', 'lBlWSg7X4Gg', 'ZyoYuyeExZo', 'alfpauUG3_M', 'G-iZ79_4vCE', 'tzkexrm9CUY', 'VWhKRMOBFfE', 'Px631F6lsYs', 'sBnX8L_g-CU', 'sQXD_EfgWD0', 'rm3ZZT8sOTA', 'bTzuy-pAX2A', 'WlJIZyGfpZw', '5TmrTkdS17U', 'ycI0VQbtd2U', 'xNh2b70f3cI', '1njHP43-Ll0', 'uT2drw7r61w', 'awTiLx-VEdk', 
# 'yDyaYSbtba0', '3G41vb-fV4c', 'PqMgbA4UKN0', 'R9VIyW-iGUA', 'Qu_u1mg1m4o', 'AZVHmcxMFf4', '_tm6p1KzaJE', 'Eb234grDK-Q', '5m75AOKFSFI', 'AyocjnhKp5o', 'K09lWcwQJFI', 'MPFIph6O7B8', 'No2GgiJtRq4', 'CJB-Vpb9dZ0', 'E4daclEkRqg', 'pdOnpcFVy3s', 'hcErelbjtrQ', '-AGCaUF8rbU', '1ZydlZMZPtg', 'fiUmDlO8Ezk', 'LdrL6SsCEE8', '7fjImLA2CXI', 'kr9RoySGKkc', 'w-8WkWCUxyI', 'KiXtfLdGzVc', '4h_FUpkoF7U', 'gAVoZP3ESfc', 'eY47_o_tNCY', 'm2mOXVK_dIM', 'CY7GA8sekqI', 'WMibKLc9Zrg', 'lqN7fj_IRZE', 'cT7_tK3ut3E', 'YgoB2ok3xTw', 'xq8eQNM0a3U', 'zCRKvDyyHmI', '__0Spwj8DkM', 'cbm1MCTobVc', 'X6HDcubgxRk', 'rP4QfWOmOpw', 'GyLNHPrOTUE', '3xf_im7VUT0', '0EfsD7xNLIo', 'UbQP8suypvg', 'y1sx729yHvA', 'heIXdS7Gs7c', 'X4EX3ISBZWo', 'GqM5imX_pI8', '_9mHi93n2AI', 'WXK2fSdb3UM', 'vezrsZv5UcE', '-TXfilKoRmE', 'zKkQ2PIjAas', 'mGKi88Rs-IU', 'FaipZCzSvj0', 'E_FGmc3EYGw', 'I0aJKy1FCpg', 'naFOiI1u3fI', '29pnyyjtTkQ', 'nrzwAxcU1bw', '7b9R82vrA40', 'L_PcJwF81t8', '3PYYadvwkOo', 'dTBLpzmbHDY', 'PkfkMNnRO14', 'WDNhl0JxXBM', 'N-cWaRRLh3k', 'ZIAYu-N98tI', '_PKbUFJ3Iu4', 'Cd_isKtGaf8', 'spkc9V8Kw1w', 'ln62u4lYhr4', 'OxX8owYW1Y8', 'D9FSc3T8PcE', 'dseCO1PhkZY', 'dcVu20XQ5og', 'xmTQA-RNygQ', 'FUb3PXoISIY', 'Yvsps9DHVcw', 'y78UVWd5PHE', 'zrb2v_f0ZYY', 'k0-KHah21w8', 'vJY5IJWq-0o', 'PlPCi6Frbak', 'FKjJyus6WOg', '8krzjlHaGes', 'tZEM5K72aVs', '4JDGFNoY-rQ', 'G1dx__P36qw', 'uUmtJIBibMM', '_NkqwMitQ8o', 'r-q5V6LDxEY', 'KzyUXF7W6sI', '-bFmDvOjYzU', 'GY9u09fyo_s', 'NQUTjitcnJk', 'V7TcEnSOR3s', 'JUVTjmB0FF4', 'T_pIJiZ8JYI', 'iaDNACXtFkw', 'YeVLBkypPRU', 'K6ppCC3lboU', 'Qyu-fZ8BOnI', 'FgkYTucBst8', 'KbVM0a1R6Sk', 'p71xuG_dP7M', '5gFe1JSNGUk', '7u6HU-wgrDo', 'VelcCEwI7Cg', '_XTYv-AP4Jk', 'ZH7RzZbakO0', '8zP3DbmOrZQ', 'tR6vIa-kWB0', 'HjNv_iTsXn8', 'LZ2giAaHNYU', 'FF_ZlPZB6fU', '3reBvys1CUg', '2ED8z3LYAdY', '29OFyXJC_uA', 'RVYBRgV-E2U', 'mBMCE5Tm25s', 'n-Knz_rdMSc', 'TNMxC4yEibM', 'rAkHU2FuksI', 'HgEo7YnvJs0', 'OxBWODQg2Yk', 't4kM9EQGMnQ', 'cQqhKzcHnAg', 'W3hw2bWaO8Q', 'astag10OjGk', 'Sy0qm5JNL6I', '_b4w1IQn5fw', 'W5XJyaRohys', 'bcS37HfErY4', 'sAu3LVktMwE', 'npq0QLNyVng', 'sMN4zi3QwgM', '4RaSOnRcwdc', 'hNPQPo8-jNk', 'MyD2BOGWqeU', 'VXd-XlweGkE', 'YKbRrpTIrOE', 'sMqtwbKc8EA', 'CLtYV7UPlCc', 'gIqXitayZ8U', 'SaP-O04wWCk', 'EmXodOLD8_I', 'jNTolnXQzT4', '-I3CACfx5JQ', '4CZkt4esv68', 'qfn6Uze6ZC0', 'pwZxSt6UtZ8', 'P22SIncobAU', 'hOrwpK91o5s', 'bDvjRgwuzpg', 'UsVPN5LVw7k', 'FEo1eDc5yrI', 'UJOjUJvfg9Q', '37BUx-rcv1Q', 'BZ1A200ru_M', 'ZMmTPq2REF0', 'iVCdSYbkA8o', 'yNU_5RTN3c0', 'T1aIYQd9jeI', 'oNFeOl7pW9s', 'EQ0uK9JLTTs', 'oNFzyiAUUNM', 'Px8H2tJwYnA', 'hDgszw3NoH0', 
# 'pJasdWMU03E', 'cDzz2-CB1-c', '-uTW_xmVVJg', '2bNopvl-IIw', 'Hk6jHf-xOAw', 'MILXwDRKctM', '6wJGZxmpr_g', '2EZ50wxosDg', 'mcc3KcYs9wg', 'SHQZRChOKZ4', 'oTKj1RwHvKM', 'vLMPigPC_0A', 'Ca332W9_Itc', 'dNKjI5qFjDQ', 'YUIJtJ3rZ2s', '5jU0ibHixfo', 'vNUluhhKBTQ', 'ymCQWxwatuk', 'Yk0VPJWLWno', 'WLIDk4hPKBY', 'G-wfEKRYmUk', 'GKZ8wjwsIlU', 'ZQNkV-u8Rq0', 'UApFgWGvMpM', 'JP4ob9RVklo', 'WdWMMv6tKLE', '5OJ3IVZ9yII', 'S2ThZYJop5E', 'Ooe3IUgemtg', 'c1adiK8nLbA', 'rO69HBG947o', 'sv5Cwl9GBh8', '0kvdlIcqDHU', 'fyFywirDlBk', 'rmRm8EsbgzI', 'WfzCxKUZO8E', 'NVZmJfONdm4', 'Ti9Yhug6ifk', 'TJOAdhWSjYA', '5iaQhoH-ga4', '-na_GQ1nqrE', 'AMMLKHCJxfM', 'lGAJ7W7m20A', '3pRX5oelR5o', '1OkUqO86TaM', 'DueF2df52IE', 'Cux0Xwvy0cU', 'u5AcUKkdSxM', 'tBL2_ABxgmA', 'v6VYsUvpKa0', 'iR-uBIiNV_o', 'UZesHZhgsOI', 'M9dYBosKGDo', 'p6CF-umWLZg', '-B_s5h44Hfo', '5RTpIudLuRE', 'ch6arSoUuNM', 'XzaJG2f6veg', 'FoO4Dgxkss8', 'n4rWSpqYsQg', 'hm9SRK22ccg', 'zdWL713IImg', 'DWwboubl-dA', 'FyVWwP4wBMk', '-jF50tMfjWM', 'FAhS4egUYXA', 'M4UhI-lEglE', 'kisHCaQOHYs', 'HCkpa6Ne9rk', 'HsOeBB5eu2k', 'pQE0eTMXQG8', 'JdStC48L5jI', 'OlhNI2c8_04', 'sIe0Fq4wNtU', 'xg1UjYhqV3U', 'rmgr2C04Dg0', 'MMU4urEIomE', 'eRVSyIXRecs', 'Jz-6H3kKJss', 'WHaQB0zmoF4', 'Utl5vwyeozE', 'gjPkuKvd6Zg', 'kKa3_ozxtfE', 'UQoBNQnDO0g', 'OC__YH4AtuU', 'z4WTKLT-3iQ', '9A1jC2zLvFo', 'ffslVfLym3k', 'uW536qrsxmY', '4DuNuTHQ5cA', 'YU6Kg3Wl-Dc', '_x79DJnHaps', 'dUXINmewH2k', 'HDHDTbB1CA8', 'S9BwPVof9oA', 'LUMaW76O9Bw', 'LIF80HqgobE', 'PJYvEM03E9w', 'dg69ceQUlLk', '_Shk3W4801w', 'UmxfxK2OV3k', 'dkywX5ng7L8', 'iD-fiOIcF1o', 'GULhrajnqoU', 'aw7YRfMLgeQ', '48d9NJXjtyo', 'JHvXNbbEBjw', 'JaGEGDneZFs', 'MQuOABovKBE', 'RGPznblXIFc', 'lHF5NK1XJqo', 'Px631F6lsYs', 'VFoUr-NQF6Y', 'F7qLKLPsArM', 'Yq6FBQXw2Mg', 'xxV15VuUiXQ', 'b93wkhn2wxM', 'nWpr3KvNDEA', 'ihbRtl-pxqs', '8Fj2ARn1WMY', 'ZRvfNrUJECo', 'GSQSBoHmG8s', 'sZ7UbC_Ujpo', '8BrX-Glym9U', 'ehjQ-E8in3I', 'x6VyJd9LVpI', 'Et_eJ6rHfLc', 'MHkZY6dQjos', 'PzhwrDgrqUA', 'JIlpEkppRPk', 'LvfJNxvOztg', 'eLlo125YYX8', '_HnLhmXSpUs', 'yDz5bRy7AgI', 'byOhPnDhe8g', 'mz5hkS41SAA', '0l-DGxTExbk', 'bE1bwwqiyiA', 'o7rFxg0HT7U', 'ISu-r7mvI60', 'p6m_7xIhuHk', 'mjPLPpwtOhc', 'uQ9goL2Bw4M', 'KxP7dUVfF80', 'lcaIMuNEUa0', 'WfP_-o7j-ns', '6ElX5oeugiw', 'SRaR1CDv38g', 'ldNSxqk2N2M', '6Udng_waiJ4', 'dXg2Z5CZle4', 'QrJ2vLrAOI8', '8-zl_669Otg', 'GvQV-8qoKFE', '2xiW1JKjrZY', 'M-Yj8W-ZPIc', 'o793_X9c3b4', 'osLOcFgReL4', 'NdSmZ2X_6-s', 'ah0cTsPXLqM', 'OTNFovBVIG4', '1680gwacKbg', 'yCVroQ-5Ojs', '2Bt-fXumeWE', 'KozgO4PQ8ps', 'C_4aMAM1ptE', 'sCHQ9a4AvOM', 'L4BQhipkK_8', 'TYuiRwFzwmk', 
# 'P-NF-7miGLo', 'qO2d9FpBzDI', 'ft00rhaFUSQ', 'tJfERzrG-D8', 'Chp9VlSs25c', 'CM1fL5D1_W8', 'SjwUehtDtS0', '6bTMAkd-EJc', 'OcCtIVzIWMg', 'ApxGBJJH0jw', 'q5GGCVIEYts', 'z2HneqfZGsM', 'wgLLPjLZz9o', 'Gm5OP6LCdk4', 'PeXpY-p5NsM', 'zAmxF52354k', 'DmQMS_qUtn8', '03-cF_ozoQs', 'WAefnKutA4E', 'Jv-8SMSgtwU', 'b1UiiG_9k1I', 'M1nu4GO4_js', 'bPjc1ZhqVAA', 'FvkokEcY3SA', 'HSoykPqSHIs', 'GHGXy_sjbgQ', 'cZlsZwcIgpc', 'jUFCevT644I', 'RJ9_xX11QfY', 'er233rSaas0', 'lnR-ehdKalQ', '-jlr_PEBuY8', 'PjFgGIuP6WY', 'S1E8SQde5rk', '1Mxw3cZa56A', '7yFkZM2w54Q', 'vmdox-V2u_I', 'qIfjibyt6pY', 'b4VfL0PbZdg', 'lQxY2s-oIak', 'Pyz73VZ_nyc', 'TySpctNzmSI', 'Yivy6UJtoN4', 'Op1lOtxdvXU', 's2d8dgZPOYE', 'tt3BSseLSWk', 'RFHvq-8np1o', 'sCHQ9a4AvOM', 'L4BQhipkK_8', 'TYuiRwFzwmk', 'P-NF-7miGLo', 'qO2d9FpBzDI', 'ft00rhaFUSQ', 'tJfERzrG-D8', 'SjwUehtDtS0', 'CM1fL5D1_W8', '6bTMAkd-EJc', 'wgLLPjLZz9o', 'Chp9VlSs25c', 'OcCtIVzIWMg', 'DmQMS_qUtn8', 'Jv-8SMSgtwU', 'ApxGBJJH0jw', 'bPjc1ZhqVAA', 'q5GGCVIEYts', 'z2HneqfZGsM', 'jUFCevT644I', '7yFkZM2w54Q', 'Gm5OP6LCdk4', 'PeXpY-p5NsM', 'zAmxF52354k', 'PjFgGIuP6WY', '-jlr_PEBuY8', '03-cF_ozoQs', 'WAefnKutA4E', 'b1UiiG_9k1I', 'Pyz73VZ_nyc', 'FvkokEcY3SA', 'M1nu4GO4_js', 'er233rSaas0', 'NuGm7XJeaTg', 'GHGXy_sjbgQ', 'HSoykPqSHIs', 'cZlsZwcIgpc', 'vmdox-V2u_I', 'RJ9_xX11QfY', 'KS-auGAIB8g', 'lnR-ehdKalQ', 'DK7MjajHMAY', 'S1E8SQde5rk', '1Mxw3cZa56A', 's2d8dgZPOYE', 'qIfjibyt6pY', 'b4VfL0PbZdg', 'Yivy6UJtoN4', 'lQxY2s-oIak', 'TySpctNzmSI', 'TRt1jbjKmyU', 'nHYiKXOP4Qc', 'Op1lOtxdvXU', 'mSwyd2QFLBU', 'DApxDxiZnpo', '_dBT9iDCRmM', '5jdwg2fzTSs', 'MjfSL4kwdsU', '7ih0Vg7jU34', '_pHI5-mF2Ck', 'TPJJ1yPP6ZI', 'Wg9EtF447Lw', '2oQN87Wlz0I', '4YCQDJlJXO0', 'Jv-8SMSgtwU', '7yFkZM2w54Q', 'CCiCRRetmyY', 'L4ZmDCAMRqY', 'kPaCsNs8kLA', 'pUTSN4fLQtk', 'z1Rzh_HaYt4', 'J2vclt1kOo8', 'oz5mwROO4so', 'PqMgbA4UKN0', 'gv9CFkbz590', 'bG0lGnoZszA', 'FYAopJdRAe4', 'cR7x7PyM888', '5lmToaQz5XQ', 'Y9UjeZBOirE', 'wrUssMJ6Y8k', 'rJQFEZnz-sM', 'jUFCevT644I', 'wrFBoBvXFT4', 'UrCAzfjBi98', '3YJ_BT5lVBc', '_HJT7tQuYFs', 'XyP6epnJ81A', 'bEHjawBxChI', 'Lcym0ybq5uE', '4DuNuTHQ5cA', 'ERN8MZl-2pw', 'QXDMJ00Y56Q', 'LmRBXH_JnlE', 's2zEfdxX1bk', 'dnV3WzoSxbE', 'hZj8G5uKwaU', '60r2LG1TlX0', 'jzTogitX1-Y', '7ACrY1u0bag', 'QPmUAfuqM08', '2bXn2F58OsM', 'aM31RyxSSCw', 'ipkPcrNsCv8', '62TubVzpiOw', 'fPgqjxBVOh8', 'kY9XESNFrxI', 'g6-aA0nuFbg', 'bNxgaOWnkFU', '2pKal5ULlww', 'kfNr2zUDEZc', 'O0DriafHhH4', 'ASmHdzkV1ek', '4_N8IyfHB48', 'uO7zUUUwz-4', 'DAvj3GG9uXQ', '-HlI0NZSXO0', 'qhBZIwunTRM', '5jttZMQX6Og', 'e2sW3nqbzjY', 'hj7v8e1uLyE', '_e8LKAGrPQ4', 
# 'A-F6OOmoPoc', 'hSwr-xEQO-8', '8Owd5xswtrU', 'vc7T9AuGXJo', '3E0M8774bFk', '6HFGrzHovSU', 'UHc32CpLUhc', '7txtAMRQxi8', 'L_0x9Vn3POA', 'MtFjfTBFPOk', 'p7VVsZ-PBpA', 'G12q4znF5zY', 'grXhTwiGFw0', 'dn3x0xBlCpA', '8-XAFqkZNXY', '9V_-4zwLlqc', 'X11xoGeX0s8', 'iJkfMHILDQc', 'q1S4KTv8qJM', 'GjwGE9Z-Kvs', 'z4SViIhpEBw', 'urYCRMMSKnI', '1zDZmIDbDO0', '0N7bSYrfOzg', '-4b-MXGwSFA', 'QbyytEdm0t4', 'Ku521etXHcM', 'Drn5hXzRaLM', 'PqMgbA4UKN0', 'G-iZ79_4vCE', 'mSwyd2QFLBU', 'sBnX8L_g-CU', '69K82Hy4koM', '2oQN87Wlz0I', 'U8TTuPA-rWM', '4yufD_Ouzlg', '2pBfKRcU9Fw', 'ycI0VQbtd2U', 'tJfERzrG-D8', 'tzkexrm9CUY', 'BlDYS_2X5wI', 'aQfY25fUf8w', 'fiUmDlO8Ezk', '_P5qPHfMypo', 'GHGXy_sjbgQ', 'fQauiGOwitE', 'VWhKRMOBFfE', 'sw8YzH1BxNs', 'LyuCyRDxpeY', '2M1gsMBqZJc', 'TjGa9suWbl0', 'Ruo0K9JDyCU', 'PhfN9XSG6dc', '8boH3J9HfeQ', 'z1Rzh_HaYt4', 'H8M7efxVaLY', 'f1ri8dYCS-g', '9rlz3xxnj68', 'lnPE6908RHQ', '0sMVeUmz7rE', 'Ll_WJWYXnhM', 'CY7GA8sekqI', 'iuBFMLwUE5U', 'Iemjun5G4Z0', 'lqN7fj_IRZE', 'ISAVbY6ZThI', 'M4UhI-lEglE', 'Qu_u1mg1m4o', '7A5ko1Pr558', '_yqQxeKHnOQ', '5-hLA805MjM', '4iNw_EWmQTE', '72flTa3iCoo', 'vR-7lmLpuqY', 'fWwEK7jr2x0', '1ZydlZMZPtg', 'kisHCaQOHYs', 'bQoEenXg9JI', 'pC9L_UI49zM', '7_1ELq9qGPo', '-rgVkUr0IRU', 'eSlhH8v09HY', '09W6Xt0zwq4', '7rJBv-rOqkE', 'MM2d7V159jE', 'E_Ryxs_dRN4', 'qFdwEcplTYw', '9Q9fQI91IYE', 'CUg6Z-dTMmA', 'Q6ItAJoPK_Y', 'oyf2Xb5ln_o', 'KFklEWsx5Aw', 'OtPE4NTESeY', '1llvqWqxstY', '8dGKA7c1aGY', 'FdVeQDpEUSw', 'LRbMQPp0yP4', 'CkWDZfg5acc', 'DnlaG5hFj10', 'iJFQNIq9nwg', 'UdtN7OP_DHQ', 'HMrce1R5Ki8', 'nyzoB0groLE', 'rPpLxjWb5HI', 'rGeIz-ucTY0', 'sTFIi8shiXs', 'xTAwA2bg7W4', 'dszLA2V0lyk', 'tOnFuB8va1A', 'WGxAMc9LpOE', 'BEFSkBJ5irg', 'Q40euF-hY7M', 'XnpjmaPpmtk', '7naItaB-7zg', 'gOLUoR2_jK8', 'sJSW_nqU6gg', '2RZY158K0gc', 'e8WRiWAA03I', 'YuG7Ceg8OYM', '6CrSiO8GmmY', 'tgzyJD9J1f8', 'yBvZeecN8Ok', 'C4gnQa6u5LA', 'Fjpk7jmkZFI', 'a0bqBNqWWMI', 'ReFdwqrQGsQ', 'H5UjL34TY84', 'JL-2In6pUqQ', 'f2LDX2ClUiM', '04XFMjMOymk', 'TyUiHafCdvM', 'l5_vrdA4uCg', 'KNGSOt2aOIQ', 'GW5ZwsNh-Lo', 'VUKN3m8wD2Q', 'EpWu8jXqK88', 'g1N07y5e6w8', 'MTNd8tlkDlk', 'FJ6Ir42fvtU', '-tcOsxWvD8U', 'C_BK7PRugK4', 'xnXONkxmxQg', '4JIueJwRyek', '0d0MPg7DxbY', 'wqRJCxDdTZU', 'OpEB6hCpIGM', 'J4EC8cDTvSg', 'LQqaUCsGSl4', '-mWcuTJpmXw', 'v7ackbOwG78', 'aEnWFucxkEY', 'dO1RiTCZFFg', 'pbE5oQQ15IQ', 'TdKhf60UbG4', 'HFalNq0_1V0', 'rcukb0KUvCU', 'zDyh-H7AAcg', 'MkdrQQO5KmM', 'cK9y-vAw7EI', 'ZGMWEaBWSbY', 'GrAozeUpEkQ', 'v7UwbJ8n9L0', 'bfM0R1eP-hI', 'X6h6d03HF38', 'lIqxcjsSJrI', 'QGPL7rKI5t4', 'uljBTtnjDLg', 'SxsTxf7XO1c', 'pVkdsKN7f84', 
# 'TdZYUE2gZTE', 'ZHzJPB_WOyA', 'RMjN58QbdGo', 'q8zFsjl4QhE', 'XNgmKyw4qfo', 'apI3SfoprOQ', 'FMih-QCIvfk', '7np8ky01L4Q', 'jtGR1t9woNE']

# # Initialize the CSV file
# csv_filename = "Sentiment_Analysis.csv"
# with open(csv_filename, 'w', newline='', encoding='utf-8') as csv_file:
#     fieldnames = ['VideoID', 'Positive%', 'Negative%', 'Neutral%']
#     writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
#     writer.writeheader()

#     for video_id in video_ids:
#         # Fetch comments for the video
#         comments = fetch_video_comments(video_id)

#         positive_count = 0
#         negative_count = 0
#         neutral_count = 0

#         for comment in comments:
#             sentiment = analyze_sentiment(comment)
#             if sentiment == "positive":
#                 positive_count += 1
#             elif sentiment == "negative":
#                 negative_count += 1
#             else:
#                 neutral_count += 1

#         total_comments = len(comments)
#         positive_percentage = (positive_count / total_comments) * 100
#         negative_percentage = (negative_count / total_comments) * 100
#         neutral_percentage = (neutral_count / total_comments) * 100

#         # Write the results to the CSV file
#         writer.writerow({'VideoID': video_id, 'Positive%': positive_percentage, 'Negative%': negative_percentage, 'Neutral%': neutral_percentage})

# print(f"Sentiment analysis results have been saved to {csv_filename}")




from textblob import TextBlob
import csv
from googleapiclient.discovery import build
import os

# Set up the YouTube Data API service
api_key = 'AIzaSyAZvvGsklJlDDtP-3t2wW8ccvHlsxW3QLo'  # Replace with your YouTube Data API key
api_service_name = 'youtube'
api_version = 'v3'
youtube = build(api_service_name, api_version, developerKey=api_key)

def fetch_video_comments(video_id):
    comments = []
    page_token = None

    while True:
        response = youtube.commentThreads().list(
            part='snippet',
            videoId=video_id,
            textFormat='plainText',
            maxResults=30000,  # Adjust this number as needed
            pageToken=page_token
        ).execute()

        for item in response.get('items', []):
            comment = item['snippet']['topLevelComment']['snippet']['textDisplay']
            comments.append(comment)

        page_token = response.get('nextPageToken')

        if not page_token:
            break

    return comments

def analyze_sentiment(comment):
    analysis = TextBlob(comment)
    sentiment = analysis.sentiment.polarity  # Range from -1 (negative) to 1 (positive)
    if sentiment > 0:
        return "positive"
    elif sentiment < 0:
        return "negative"
    else:   
        return "neutral"

# Sample dataset with video IDs
video_ids = [ 'oTKj1RwHvKM', 'vLMPigPC_0A', 'dNKjI5qFjDQ', 'YUIJtJ3rZ2s', '5jU0ibHixfo', 'vNUluhhKBTQ', 'ymCQWxwatuk', 'Yk0VPJWLWno', 
             'WLIDk4hPKBY', 'G-wfEKRYmUk', 'GKZ8wjwsIlU', 'ZQNkV-u8Rq0', 'UApFgWGvMpM', 'JP4ob9RVklo', 'WdWMMv6tKLE', '5OJ3IVZ9yII', 
             'S2ThZYJop5E', 'Ooe3IUgemtg', 'c1adiK8nLbA', 'rO69HBG947o', 'sv5Cwl9GBh8', '0kvdlIcqDHU', 'fyFywirDlBk', 'rmRm8EsbgzI', 
             'WfzCxKUZO8E', 'NVZmJfONdm4', 'Ti9Yhug6ifk', 'TJOAdhWSjYA', '5iaQhoH-ga4', '-na_GQ1nqrE', 'AMMLKHCJxfM', 'lGAJ7W7m20A', 
             '3pRX5oelR5o', '1OkUqO86TaM', 'DueF2df52IE', 'Cux0Xwvy0cU', 'u5AcUKkdSxM', 'tBL2_ABxgmA', 'v6VYsUvpKa0', 'iR-uBIiNV_o', 
             'UZesHZhgsOI', 'M9dYBosKGDo', 'p6CF-umWLZg', '-B_s5h44Hfo', '5RTpIudLuRE', 'ch6arSoUuNM', 'XzaJG2f6veg', 'FoO4Dgxkss8', 
             'n4rWSpqYsQg', 'hm9SRK22ccg', 'zdWL713IImg', 'DWwboubl-dA', 'FyVWwP4wBMk', '-jF50tMfjWM', 'FAhS4egUYXA', 'M4UhI-lEglE', 
             'kisHCaQOHYs', 'HCkpa6Ne9rk', 'HsOeBB5eu2k', 'pQE0eTMXQG8', 'JdStC48L5jI', 'OlhNI2c8_04', 'sIe0Fq4wNtU', 'xg1UjYhqV3U', 
             'rmgr2C04Dg0', 'MMU4urEIomE', 'eRVSyIXRecs', 'Jz-6H3kKJss', 'WHaQB0zmoF4', 'Utl5vwyeozE', 'gjPkuKvd6Zg', 'kKa3_ozxtfE', 
             'UQoBNQnDO0g', 'OC__YH4AtuU', 'z4WTKLT-3iQ', '9A1jC2zLvFo', 'ffslVfLym3k', 'uW536qrsxmY', '4DuNuTHQ5cA', 'YU6Kg3Wl-Dc', 
             '_x79DJnHaps', 'dUXINmewH2k', 'HDHDTbB1CA8', 'S9BwPVof9oA', 'LUMaW76O9Bw', 'LIF80HqgobE', 'PJYvEM03E9w', 'dg69ceQUlLk', 
             '_Shk3W4801w', 'UmxfxK2OV3k', 'dkywX5ng7L8', 'iD-fiOIcF1o', 'GULhrajnqoU', 'aw7YRfMLgeQ', '48d9NJXjtyo', 'JHvXNbbEBjw', 
             'JaGEGDneZFs', 'MQuOABovKBE', 'RGPznblXIFc', 'lHF5NK1XJqo', 'Px631F6lsYs', 'VFoUr-NQF6Y', 'F7qLKLPsArM', 'Yq6FBQXw2Mg', 
             'xxV15VuUiXQ', 'b93wkhn2wxM', 'nWpr3KvNDEA', 'ihbRtl-pxqs', '8Fj2ARn1WMY', 'ZRvfNrUJECo', 'GSQSBoHmG8s', 'sZ7UbC_Ujpo', 
             '8BrX-Glym9U', 'ehjQ-E8in3I', 'x6VyJd9LVpI', 'Et_eJ6rHfLc', 'MHkZY6dQjos', 'PzhwrDgrqUA', 'JIlpEkppRPk', 'LvfJNxvOztg', 
             'eLlo125YYX8', '_HnLhmXSpUs', 'yDz5bRy7AgI', 'byOhPnDhe8g', 'mz5hkS41SAA', '0l-DGxTExbk', 'bE1bwwqiyiA', 'o7rFxg0HT7U', 
             'ISu-r7mvI60', 'p6m_7xIhuHk', 'mjPLPpwtOhc', 'uQ9goL2Bw4M', 'KxP7dUVfF80', 'lcaIMuNEUa0', 'WfP_-o7j-ns', '6ElX5oeugiw', 
             'SRaR1CDv38g', 'ldNSxqk2N2M', '6Udng_waiJ4', 'dXg2Z5CZle4', 'QrJ2vLrAOI8', '8-zl_669Otg', 'GvQV-8qoKFE', '2xiW1JKjrZY', 
             'M-Yj8W-ZPIc', 'o793_X9c3b4', 'osLOcFgReL4', 'NdSmZ2X_6-s', 'ah0cTsPXLqM', 'OTNFovBVIG4', '1680gwacKbg', 'yCVroQ-5Ojs', 
             '2Bt-fXumeWE', 'KozgO4PQ8ps', 'C_4aMAM1ptE', 'sCHQ9a4AvOM', 'L4BQhipkK_8', 'TYuiRwFzwmk',
             'P-NF-7miGLo', 'qO2d9FpBzDI', 'ft00rhaFUSQ', 'tJfERzrG-D8', 'Chp9VlSs25c', 'CM1fL5D1_W8', 'SjwUehtDtS0', '6bTMAkd-EJc', 'OcCtIVzIWMg', 
             'ApxGBJJH0jw', 'q5GGCVIEYts', 'z2HneqfZGsM', 'wgLLPjLZz9o', 'Gm5OP6LCdk4', 'PeXpY-p5NsM', 'zAmxF52354k', 'DmQMS_qUtn8', '03-cF_ozoQs', 
             'WAefnKutA4E', 'Jv-8SMSgtwU', 'b1UiiG_9k1I', 'M1nu4GO4_js', 'bPjc1ZhqVAA', 'FvkokEcY3SA', 'HSoykPqSHIs', 'GHGXy_sjbgQ', 'cZlsZwcIgpc', 
             'jUFCevT644I', 'RJ9_xX11QfY', 'er233rSaas0', 'lnR-ehdKalQ', '-jlr_PEBuY8', 'PjFgGIuP6WY', 'S1E8SQde5rk', '1Mxw3cZa56A', '7yFkZM2w54Q', 
             'vmdox-V2u_I', 'qIfjibyt6pY', 'b4VfL0PbZdg', 'lQxY2s-oIak', 'Pyz73VZ_nyc', 'TySpctNzmSI', 'Yivy6UJtoN4', 'Op1lOtxdvXU', 's2d8dgZPOYE',
             'tt3BSseLSWk', 'RFHvq-8np1o', 'sCHQ9a4AvOM', 'L4BQhipkK_8', 'TYuiRwFzwmk', 'P-NF-7miGLo', 'qO2d9FpBzDI', 'ft00rhaFUSQ', 'tJfERzrG-D8', 
             'SjwUehtDtS0', 'CM1fL5D1_W8', '6bTMAkd-EJc', 'wgLLPjLZz9o', 'Chp9VlSs25c', 'OcCtIVzIWMg', 'DmQMS_qUtn8', 'Jv-8SMSgtwU', 'ApxGBJJH0jw',
             'bPjc1ZhqVAA', 'q5GGCVIEYts', 'z2HneqfZGsM', 'jUFCevT644I', '7yFkZM2w54Q', 'Gm5OP6LCdk4', 'PeXpY-p5NsM', 'zAmxF52354k', 'PjFgGIuP6WY',
             '-jlr_PEBuY8', '03-cF_ozoQs', 'WAefnKutA4E', 'b1UiiG_9k1I', 'Pyz73VZ_nyc', 'FvkokEcY3SA', 'M1nu4GO4_js', 'er233rSaas0', 'NuGm7XJeaTg',
             'GHGXy_sjbgQ', 'HSoykPqSHIs', 'cZlsZwcIgpc', 'vmdox-V2u_I', 'RJ9_xX11QfY', 'KS-auGAIB8g', 'lnR-ehdKalQ', 'DK7MjajHMAY', 'S1E8SQde5rk',
             '1Mxw3cZa56A', 's2d8dgZPOYE', 'qIfjibyt6pY', 'b4VfL0PbZdg', 'Yivy6UJtoN4', 'lQxY2s-oIak', 'TySpctNzmSI', 'TRt1jbjKmyU', 'nHYiKXOP4Qc',
             'Op1lOtxdvXU', 'mSwyd2QFLBU', 'DApxDxiZnpo', '_dBT9iDCRmM', '5jdwg2fzTSs', 'MjfSL4kwdsU', '7ih0Vg7jU34', '_pHI5-mF2Ck', 'TPJJ1yPP6ZI', 
             'Wg9EtF447Lw', '2oQN87Wlz0I', '4YCQDJlJXO0', 'Jv-8SMSgtwU', '7yFkZM2w54Q', 'CCiCRRetmyY', 'L4ZmDCAMRqY', 'kPaCsNs8kLA', 'pUTSN4fLQtk',
             'z1Rzh_HaYt4', 'J2vclt1kOo8', 'oz5mwROO4so', 'PqMgbA4UKN0', 'gv9CFkbz590', 'bG0lGnoZszA', 'FYAopJdRAe4', 'cR7x7PyM888', '5lmToaQz5XQ',
             'Y9UjeZBOirE', 'wrUssMJ6Y8k', 'rJQFEZnz-sM', 'jUFCevT644I', 'wrFBoBvXFT4', 'UrCAzfjBi98', '3YJ_BT5lVBc', '_HJT7tQuYFs', 'XyP6epnJ81A',
             'bEHjawBxChI', 'Lcym0ybq5uE', '4DuNuTHQ5cA', 'ERN8MZl-2pw', 'QXDMJ00Y56Q', 'LmRBXH_JnlE', 's2zEfdxX1bk', 'dnV3WzoSxbE', 'hZj8G5uKwaU', 
             '60r2LG1TlX0', 'jzTogitX1-Y', '7ACrY1u0bag', 'QPmUAfuqM08', '2bXn2F58OsM', 'aM31RyxSSCw', 'ipkPcrNsCv8', '62TubVzpiOw', 'fPgqjxBVOh8', 
             'kY9XESNFrxI', 'g6-aA0nuFbg', 'bNxgaOWnkFU', '2pKal5ULlww', 'kfNr2zUDEZc', 'O0DriafHhH4', 'ASmHdzkV1ek', '4_N8IyfHB48', 'uO7zUUUwz-4', 
             'DAvj3GG9uXQ', '-HlI0NZSXO0', 'qhBZIwunTRM', '5jttZMQX6Og', 'e2sW3nqbzjY', 'hj7v8e1uLyE', '_e8LKAGrPQ4', 
             'A-F6OOmoPoc', 'hSwr-xEQO-8', '8Owd5xswtrU', 'vc7T9AuGXJo', '3E0M8774bFk', '6HFGrzHovSU', 'UHc32CpLUhc', '7txtAMRQxi8', 'L_0x9Vn3POA', 
             'MtFjfTBFPOk', 'p7VVsZ-PBpA', 'G12q4znF5zY', 'grXhTwiGFw0', 'dn3x0xBlCpA', '8-XAFqkZNXY', '9V_-4zwLlqc', 'X11xoGeX0s8', 'iJkfMHILDQc', 
             'q1S4KTv8qJM', 'GjwGE9Z-Kvs', 'z4SViIhpEBw', 'urYCRMMSKnI', '1zDZmIDbDO0', '0N7bSYrfOzg', '-4b-MXGwSFA', 'QbyytEdm0t4', 'Ku521etXHcM', 
             'Drn5hXzRaLM', 'PqMgbA4UKN0', 'G-iZ79_4vCE', 'mSwyd2QFLBU', 'sBnX8L_g-CU', '69K82Hy4koM', '2oQN87Wlz0I', 'U8TTuPA-rWM', '4yufD_Ouzlg',
             '2pBfKRcU9Fw', 'ycI0VQbtd2U', 'tJfERzrG-D8', 'tzkexrm9CUY', 'BlDYS_2X5wI', 'aQfY25fUf8w', 'fiUmDlO8Ezk', '_P5qPHfMypo', 'GHGXy_sjbgQ',
             'fQauiGOwitE', 'VWhKRMOBFfE', 'sw8YzH1BxNs', 'LyuCyRDxpeY', '2M1gsMBqZJc', 'TjGa9suWbl0', 'Ruo0K9JDyCU', 'PhfN9XSG6dc', '8boH3J9HfeQ',
             'z1Rzh_HaYt4', 'H8M7efxVaLY', 'f1ri8dYCS-g', '9rlz3xxnj68', 'lnPE6908RHQ', '0sMVeUmz7rE', 'Ll_WJWYXnhM', 'CY7GA8sekqI', 'iuBFMLwUE5U', 
             'Iemjun5G4Z0', 'lqN7fj_IRZE', 'ISAVbY6ZThI', 'M4UhI-lEglE', 'Qu_u1mg1m4o', '7A5ko1Pr558', '_yqQxeKHnOQ', '5-hLA805MjM', '4iNw_EWmQTE', 
             '72flTa3iCoo', 'vR-7lmLpuqY', 'fWwEK7jr2x0', '1ZydlZMZPtg', 'kisHCaQOHYs', 'bQoEenXg9JI', 'pC9L_UI49zM', '7_1ELq9qGPo', '-rgVkUr0IRU',
             'eSlhH8v09HY', '09W6Xt0zwq4',  'MM2d7V159jE', 'E_Ryxs_dRN4', 'qFdwEcplTYw', '9Q9fQI91IYE', 'CUg6Z-dTMmA', 'Q6ItAJoPK_Y', 'oyf2Xb5ln_o', 
             'KFklEWsx5Aw', 'OtPE4NTESeY', '8dGKA7c1aGY', 'FdVeQDpEUSw', 'LRbMQPp0yP4', 'CkWDZfg5acc', 'DnlaG5hFj10','iJFQNIq9nwg', 'UdtN7OP_DHQ', 
             'HMrce1R5Ki8', 'nyzoB0groLE', 'rPpLxjWb5HI', 'rGeIz-ucTY0', 'sTFIi8shiXs', 'xTAwA2bg7W4', 'dszLA2V0lyk',  'tOnFuB8va1A', 'WGxAMc9LpOE', 
             'BEFSkBJ5irg', 'Q40euF-hY7M', 'XnpjmaPpmtk', '7naItaB-7zg', 'sJSW_nqU6gg', '2RZY158K0gc', 'e8WRiWAA03I', 'YuG7Ceg8OYM', '6CrSiO8GmmY', 
             'tgzyJD9J1f8', 'yBvZeecN8Ok', 'C4gnQa6u5LA', 'Fjpk7jmkZFI', 'a0bqBNqWWMI', 'ReFdwqrQGsQ', 'H5UjL34TY84', 'JL-2In6pUqQ', 'f2LDX2ClUiM', 
             '04XFMjMOymk', 'TyUiHafCdvM', 'l5_vrdA4uCg', 'KNGSOt2aOIQ', 'GW5ZwsNh-Lo', 'VUKN3m8wD2Q', 'EpWu8jXqK88', 'g1N07y5e6w8', 'MTNd8tlkDlk', 
             'FJ6Ir42fvtU', '-tcOsxWvD8U', 'C_BK7PRugK4', 'xnXONkxmxQg', '4JIueJwRyek', '0d0MPg7DxbY', 'wqRJCxDdTZU', 'OpEB6hCpIGM', 'J4EC8cDTvSg', 
             'LQqaUCsGSl4', '-mWcuTJpmXw', 'v7ackbOwG78', 'aEnWFucxkEY', 'dO1RiTCZFFg', 'pbE5oQQ15IQ', 'TdKhf60UbG4', 'HFalNq0_1V0', 'rcukb0KUvCU', 
             'zDyh-H7AAcg', 'MkdrQQO5KmM', 'cK9y-vAw7EI', 'ZGMWEaBWSbY', 'GrAozeUpEkQ', 'v7UwbJ8n9L0', 'bfM0R1eP-hI', 'X6h6d03HF38', 'lIqxcjsSJrI', 
             'QGPL7rKI5t4', 'uljBTtnjDLg',  'ZHzJPB_WOyA', 'RMjN58QbdGo', 'q8zFsjl4QhE', 'XNgmKyw4qfo', 'apI3SfoprOQ', 'FMih-QCIvfk', '7np8ky01L4Q', 'jtGR1t9woNE']

# Initialize the CSV file
csv_filename = "Sentiment_Analysis36.csv"
with open(csv_filename, 'w', newline='', encoding='utf-8') as csv_file:
    fieldnames = ['VideoID', 'Positive%', 'Negative%', 'Neutral%']
    writer = csv.DictWriter(csv_file, fieldnames=fieldnames)
    writer.writeheader()

    for video_id in video_ids:
        # Fetch comments for the video
        comments = fetch_video_comments(video_id)

        positive_count = 0
        negative_count = 0
        neutral_count = 0

        try:
            for comment in comments:
                sentiment = analyze_sentiment(comment)
                if sentiment == "positive":
                    positive_count += 1
                elif sentiment == "negative":
                    negative_count += 1
                else:
                    neutral_count += 1

            total_comments = len(comments)
            positive_percentage = (positive_count / total_comments) * 100
            negative_percentage = (negative_count / total_comments) * 100
            neutral_percentage = (neutral_count / total_comments) * 100

        except ZeroDivisionError:
            total_comments = 0
            positive_percentage = 0
            negative_percentage = 0
            neutral_percentage = 0

        # Write the results to the CSV file
        writer.writerow({'VideoID': video_id, 'Positive%': positive_percentage, 'Negative%': negative_percentage, 'Neutral%': neutral_percentage})

print(f"Sentiment analysis results have been saved to {csv_filename}")
