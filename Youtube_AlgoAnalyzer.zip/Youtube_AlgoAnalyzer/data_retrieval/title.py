from googleapiclient.discovery import build
from openpyxl import Workbook

API_KEY = 'AIzaSyCKOkfRrWboTpU1LUyVuOiUFbVq_j_QVSM'

youtube = build('youtube', 'v3', developerKey=API_KEY)

search = youtube.search().list(
    q='recycled energy',
    type='video',
    part='id,snippet',
    maxResults=100  
).execute()

workbook = Workbook()
worksheet = workbook.active
worksheet.append(['Title', 'Video ID', 'Views', 'Likes', 'Comments','keyword'])

for s in search.get('items', []):
    if s['id']['kind'] == 'youtube#video':
        video_id = s['id']['videoId']
        video_title = s['snippet']['title']
        video_details = youtube.videos().list(
            part='snippet,statistics',
            id=video_id
        ).execute()

        video_snippet = video_details['items'][0]['snippet']
        video_description = video_snippet['description']
        video_statistics = video_details['items'][0]['statistics']
        video_views = video_statistics['viewCount'] if 'viewCount' in video_statistics else 0
        video_likes = video_statistics['likeCount'] if 'likeCount' in video_statistics else 0
        video_comments = video_statistics['commentCount'] if 'commentCount' in video_statistics else 0
        keyword=''
        worksheet.append([video_title, video_id, video_views,video_likes, video_comments,keyword])

excel_path = 'youtube_info.xlsx'
workbook.save(excel_path)

print(f'Data has been retrieved to {excel_path}')
