# from googleapiclient.discovery import build

# # Set up the YouTube Data API service
# api_key = 'AIzaSyCKOkfRrWboTpU1LUyVuOiUFbVq_j_QVSM'
# api_service_name = 'youtube'
# api_version = 'v3'
# youtube = build(api_service_name, api_version, developerKey=api_key)

# # Specify the YouTube video ID
# video_id = 'z-k5uS7ALXk'

# # Make a request to the YouTube API to retrieve the list of channel IDs that viewed the video
# response = youtube.videos().list(
#     part='statistics',
#     id=video_id
# ).execute()

# # Extract the view count from the response
# view_count = response['items'][0]['statistics']['viewCount']

# # Use the view count to retrieve a list of channel IDs that viewed the video
# channel_ids = []
# page_token = None

# while True:
#     response = youtube.search().list(
#         part='snippet',
#         type='channel',
#         videoCategoryId='UC',
#         maxResults=50,  # You can adjust this number
#         order='viewCount',
#         q=f'video_id:{video_id}',
#         pageToken=page_token
#     ).execute()

#     for item in response.get('items', []):
#         channel_id = item['snippet']['channelId']
#         channel_ids.append(channel_id)

#     page_token = response.get('nextPageToken')

#     if not page_token:
#         break

# # Print the list of channel IDs
# print(channel_ids)




from googleapiclient.discovery import build

# Set up the YouTube Data API service
api_key = 'AIzaSyCKOkfRrWboTpU1LUyVuOiUFbVq_j_QVSM'
api_service_name = 'youtube'
api_version = 'v3'
youtube = build(api_service_name, api_version, developerKey=api_key)

# Specify the YouTube video ID
video_id = 's3ScJ_FwaZk'

# Use the video ID to retrieve a list of channel IDs that viewed the video
channel_ids = []
page_token = None

while True:
    response = youtube.videos().list(
        part='snippet',
        type='channel',
        maxResults=50,  # You can adjust this number
        order='viewCount',
        q=f'video_id:{video_id}',
        pageToken=page_token
    ).execute()

    for item in response.get('items', []):
        channel_id = item['snippet']['channelId']
        channel_ids.append(channel_id)

    page_token = response.get('nextPageToken')

    if not page_token:
        break

# Print the list of channel IDs
print(channel_ids)
